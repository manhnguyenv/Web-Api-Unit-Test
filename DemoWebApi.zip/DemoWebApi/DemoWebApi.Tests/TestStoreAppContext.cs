﻿using DemoWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWebApi.Tests
{
        public class TestStoreAppContext
        {
            public TestStoreAppContext()
            {
                this.Contact = new TestContactDbSet();
            }

            public DbSet<Contact> Contact { get; set; }

            public int SaveChanges()
            {
                return 0;
            }

            public void MarkAsModified(Contact item) { }
            public void Dispose() { }
        }
    
}
