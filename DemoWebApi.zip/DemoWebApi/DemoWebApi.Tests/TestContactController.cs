﻿using DemoWebApi.Controllers;
using DemoWebApi.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Results;

namespace DemoWebApi.Tests
{
    [TestClass]
    public class TestContactController
    {

        [TestMethod]
        public void GetAllProducts_ShouldReturnAllProducts()
        {
            var testProducts = GetContact();
            IContactRepository _repository = new ContactRepository();
            var controller = new ContactsEFController(_repository);

            var result = controller.GetContacts() as List<Contact>;
            Assert.AreEqual(result.Count, testProducts.Count);
        }


        List<Contact> GetContact()
        {
            var testProducts = new List<Contact>();
            testProducts.Add(new Contact { Id = 1, FirstName = "test1", LastName = "test2" });
            return testProducts;
        }
    }
}
