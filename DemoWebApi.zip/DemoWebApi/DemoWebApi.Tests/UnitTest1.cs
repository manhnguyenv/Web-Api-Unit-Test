﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using DemoWebApi.Models;
using DemoWebApi.Controllers;

namespace DemoWebApi.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void GetAllContacts()
        {
            var contacts = GetContacts();
            var controller = new ContactsEFController();
            var v = controller.GetContacts();
            var result = controller.GetContacts() as List<Contact>;
            Assert.AreEqual(contacts.Count, result.Count);
        }

        private List<Contact> GetContacts()
        {
            var testContacts = new List<Contact>();
            testContacts.Add(new Contact {Id=1, FirstName="test1",LastName="test2" });
            testContacts.Add(new Contact { Id = 2, FirstName = "", LastName = "" });
            testContacts.Add(new Contact { Id = -1, FirstName = null, LastName = null });
            testContacts.Add(new Contact { Id = 2, FirstName = "test1", LastName = "test2" });
            return testContacts;
        }
    }
}
