﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace DemoWebApi.Models
{
    public class ContactRepository : IContactRepository
    {
        private DemoWebApiContext db = new DemoWebApiContext();
        public IQueryable<Contact> GetContacts()
        {
            return db.Contacts;
        }

        public Contact GetContact(int id)
        {
            Contact contact = db.Contacts.Find(id);
            return contact;
        }

        public Contact PostContact(Contact contact)
        {
            db.Contacts.Add(contact);
            db.SaveChanges();
            return contact;
        }

        public Contact PutContact(int id, Contact contact)
        {
            db.Entry(contact).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactExists(id))
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }

            return contact;
        }
        public Contact DeleteContact(int id)
        {
            Contact contact = db.Contacts.Find(id);
            
            db.Contacts.Remove(contact);
            db.SaveChanges();

            return contact;
        }

        private bool ContactExists(int id)
        {
            return db.Contacts.Count(e => e.Id == id) > 0;
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (db != null)
                {
                    db.Dispose();
                    db = null;
                }
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}