﻿using DemoWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoWebApi.Models
{
    public interface IContactRepository
    {
        IQueryable<Contact> GetContacts();
        Contact GetContact(int id);
        Contact PostContact(Contact contact);
        Contact PutContact(int id, Contact contact);
        Contact DeleteContact(int id);
    }
}
