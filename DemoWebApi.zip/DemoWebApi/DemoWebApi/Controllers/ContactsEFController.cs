﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using DemoWebApi.Models;

namespace DemoWebApi.Controllers
{
    [RoutePrefix("api/ContactsEF")]
    public class ContactsEFController : ApiController
    {
        //private DemoWebApiContext db = new DemoWebApiContext();
        IContactRepository _repository = new ContactRepository();

        public ContactsEFController()
        {

        }

        public ContactsEFController(IContactRepository context)
        {
            _repository = context;
        }

        // GET: api/ContactsEF
        [Route("")]
        [HttpGet]
        public IQueryable<Contact> GetContacts()
        {
            return _repository.GetContacts();
            //return db.Contacts;
        }

        // GET: api/ContactsEF/5
        [Route("{id}")]
        [HttpGet]
        [ResponseType(typeof(Contact))]
        public IHttpActionResult GetContact(int id)
        {
            //Contact contact = db.Contacts.Find(id);
            Contact contact = _repository.GetContact(id);
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }

        // POST: api/ContactsEF
        [ResponseType(typeof(Contact))]
        [Route("")]
        [HttpPost]
        public IHttpActionResult PostContact(Contact contact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _repository.PostContact(contact);
            //db.Contacts.Add(contact);
            //db.SaveChanges();
            return Ok(contact); // CreatedAtRoute("DefaultApi", new { id = contact.Id }, contact);
        }

        // PUT: api/ContactsEF/5
        [ResponseType(typeof(Contact))]
        [Route("{id}")]
        [HttpPut]
        public IHttpActionResult PutContact(int id, Contact contact)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != contact.Id)
            {
                return BadRequest();
            }
            _repository.PutContact(id, contact);
             return StatusCode(HttpStatusCode.NoContent);
        }

        // DELETE: api/ContactsEF/5
        [ResponseType(typeof(Contact))]
        [Route("{id}")]
        [HttpDelete]
        public IHttpActionResult DeleteContact(int id)
        {
            Contact contact = _repository.DeleteContact(id);
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }

    }
}