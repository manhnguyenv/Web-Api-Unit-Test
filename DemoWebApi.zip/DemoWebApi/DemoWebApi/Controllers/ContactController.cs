﻿using DemoWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace DemoWebApi.Controllers
{
    [RoutePrefix("api/Contact")]
    public class ContactController : ApiController
    {
        Contact[] contacts = new Contact[]
        {
           new Contact() { Id=0, FirstName="Man1", LastName="Man1" },
           new Contact() { Id=1, FirstName="Man2", LastName="Man2" },
           new Contact() { Id=2, FirstName="Man3", LastName="Man3" }
        };
        // GET: api/Contact
        [Route()]
        public IEnumerable<Contact> Get()
        {
            return contacts;
        }

        // GET: api/Contact/5
        [Route("{id:int}")]
        [HttpGet]
        public IHttpActionResult FindById(int id)
        {
            Contact contact = contacts.FirstOrDefault(c => c.Id == id);
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }

        // GET: api/Contact/Man1
        [Route("{name}")]
        public IHttpActionResult FindByName(string name)
        {
            Contact[] contact = contacts.Where<Contact>(c => c.FirstName.Contains(name)).ToArray<Contact>();
            if (contact == null)
            {
                return NotFound();
            }
            return Ok(contact);
        }
        // POST: api/Contact

        [Route("")]
        [HttpPost]
        public IEnumerable<Contact> Post([FromBody]Contact newContact)
        {
            List<Contact> contactList = contacts.ToList<Contact>();
            newContact.Id = contactList.Count;
            contactList.Add(newContact);
            contacts = contactList.ToArray();
            return contacts;
        }

        // PUT: api/Contact/5
        [Route("{id:int}")]
        public IEnumerable<Contact> Put(int id, [FromBody]Contact existingContact)
        {
            Contact contact = contacts.FirstOrDefault(c => c.Id == id);
            if(contact!=null)
            {
                contact.FirstName = existingContact.FirstName;
                contact.LastName = existingContact.LastName;
            }
            
            return contacts;
        }

        // DELETE: api/Contact/5
        [Route("{id:int}")]
        public IEnumerable<Contact> Delete(int id)
        {
            contacts = contacts.Where<Contact>(c => c.Id == id).ToArray<Contact>();
            return contacts;
        }
    }
}
